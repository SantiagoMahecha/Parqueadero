<?php

namespace App\Controllers;

class Home extends BaseController
{

    public function menu()
    {
        return view('MenuPrincipal');
    }
    public function registro()
    {
        return view('Registro');
    }
    public function consultar()
    {
        return view('Consultar');
    }
    public function salida()
    {
        return view('salida');
    }
}
