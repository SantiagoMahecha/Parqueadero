<!DOCTYPE html>
<html>
<head>
    <title>Consulta de Parqueaderos</title>
    <style>
        /* Estilos CSS aquí */
        .container {
            width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f2f2f2;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        h1 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <?php
    // Establecer la conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "parqueadero";

    $conn = mysqli_connect($servername, $username, $password, $database);

    // Verificar la conexión
    if (!$conn) {
        die("Error al conectar a la base de datos: " . mysqli_connect_error());
    }

    // Obtener los espacios de estacionamiento disponibles
    $sql_disponibles = "SELECT id FROM Espacios WHERE disponible = 1";
    $result_disponibles = mysqli_query($conn, $sql_disponibles);
    $espacios_disponibles = mysqli_fetch_all($result_disponibles, MYSQLI_ASSOC);

    // Obtener los espacios de estacionamiento ocupados y la información de los vehículos
    $sql_ocupados = "SELECT E.id AS espacio_id, V.marca, V.modelo FROM Espacios E INNER JOIN Registro R ON E.id = R.espacio_id INNER JOIN Vehiculos V ON R.vehiculo_id = V.id WHERE E.disponible = 0";
    $result_ocupados = mysqli_query($conn, $sql_ocupados);
    $espacios_ocupados = mysqli_fetch_all($result_ocupados, MYSQLI_ASSOC);
    ?>

    <div class="container">
        <h1>Consulta de Parqueaderos</h1>
    
        <h2>Parqueaderos Disponibles</h2>
        <table>
            <thead>
                <tr>
                    <th>ID Espacio</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($espacios_disponibles as $espacio) {
                    echo "<tr><td>" . $espacio["id"] . "</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <h2>Parqueaderos Ocupados</h2>
        <table>
            <thead>
                <tr>
                    <th>ID Espacio</th>
                    <th>Marca del Vehículo</th>
                    <th>Modelo del Vehículo</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($espacios_ocupados as $espacio) {
                    echo "<tr><td>" . $espacio["espacio_id"] . "</td><td>" . $espacio["marca"] . "</td><td>" . $espacio["modelo"] . "</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
