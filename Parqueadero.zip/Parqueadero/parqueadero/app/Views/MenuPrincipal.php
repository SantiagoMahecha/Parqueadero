<!DOCTYPE html>
<html>
<head>
    <title>Menú Principal - Parking</title>
    <style>
        body {
            background-color: #f2f2f2;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        ul {
            list-style-type: none;
            padding: 0;
            margin: 20px 0;
        }

        li {
            margin-bottom: 10px;
        }

        li a {
            display: block;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        li a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Menú Principal - Parking</h1>
        <ul>
            <li><a href="/menu/registro">Registrar Vehiculo</a></li>
            <li><a href="/menu/consultar">Consultar Parqueadero</a></li>
            <li><a href="/menu/salida">Salida Vehiculo</a></li>
        </ul>
    </div>
</body>
</html>
