<!DOCTYPE html>
<html>
<head>
    <title>Salida de Parking</title>
    <style>
        /* Estilos CSS aquí */
        .container {
            width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f2f2f2;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        h1 {
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            display: block;
            width: 100%;
            margin-top: 20px;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <?php
    // Establecer la conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "parqueadero";

    $conn = mysqli_connect($servername, $username, $password, $database);

    // Verificar la conexión
    if (!$conn) {
        die("Error al conectar a la base de datos: " . mysqli_connect_error());
    }

    // Función para calcular el valor a pagar
    function calcularValorAPagar($horaEntrada, $horaSalida) {
        $entrada = new DateTime($horaEntrada);
        $salida = new DateTime($horaSalida);

        $diferenciaMinutos = $salida->diff($entrada)->i;
        $horas = ceil($diferenciaMinutos / 10);
        $valor_total_tiempo = $horas * 10000; // Asignar tarifa fija de 10 unidades monetarias por hora

        return $valor_total_tiempo;
    }

    // Procesar el formulario de salida
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $registro_id = $_POST["registro_id"];
        $horaSalida = $_POST["hora_salida"];

        // Obtener la hora de entrada del registro
        $sql_info = "SELECT hora_entrada FROM Registro WHERE id = '$registro_id'";
        $result_info = mysqli_query($conn, $sql_info);
        $info = mysqli_fetch_assoc($result_info);
        $horaEntrada = $info["hora_entrada"];

        // Calcular el valor a pagar
        $valor_total_tiempo = calcularValorAPagar($horaEntrada, $horaSalida);

        // Actualizar el registro con la hora de salida y el valor a pagar
        $sql_update = "UPDATE Registro SET hora_salida = '$horaSalida', valor_total_tiempo = '$valor_total_tiempo' WHERE id = '$registro_id'";
        mysqli_query($conn, $sql_update);

        // Marcar el espacio como disponible en la tabla Espacio
        $registro_info = mysqli_fetch_assoc(mysqli_query($conn, "SELECT espacio_id FROM Registro WHERE id = '$registro_id'"));
        $espacio_id = $registro_info['espacio_id'];
        mysqli_query($conn, "UPDATE Espacios SET disponible = 1 WHERE id = '$espacio_id'");

        echo "Salida registrada exitosamente. Valor a pagar: $" . $valor_total_tiempo;
    }

    // Obtener los registros de parking activos
    $sql_registros = "SELECT R.id, R.espacio_id, V.marca, V.modelo FROM Registro R INNER JOIN Vehiculos V ON R.vehiculo_id = V.id WHERE R.hora_salida IS NULL";
    $result_registros = mysqli_query($conn, $sql_registros);
    $registros_activos = mysqli_fetch_all($result_registros, MYSQLI_ASSOC);
    ?>

    <div class="container">
        <h1>Salida de Parking</h1>

        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="registro_id">Registro:</label>
            <select name="registro_id" id="registro_id" required>
                <?php
                foreach ($registros_activos as $registro) {
                    echo "<option value='" . $registro["id"] . "'>" . $registro["marca"] . " " . $registro["modelo"] . " - Espacio: " . $registro["espacio_id"] . "</option>";
                }
                ?>
            </select><br><br>

            <label for="hora_salida">Hora de salida:</label>
            <input type="datetime-local" name="hora_salida" id="hora_salida" required><br><br>

            <input type="submit" value="Registrar salida">
        </form>
    </div>
</body>
</html>
