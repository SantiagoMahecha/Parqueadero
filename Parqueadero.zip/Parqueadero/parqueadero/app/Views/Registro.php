<!DOCTYPE html>
<html>
<head>
    <title>Registro de Parking</title>
    <style>
        /* Estilos CSS aquí */
        .container {
            width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f2f2f2;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        h1 {
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            display: block;
            width: 100%;
            margin-top: 20px;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <?php
    // Establecer la conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "parqueadero";

    $conn = mysqli_connect($servername, $username, $password, $database);

    // Verificar la conexión
    if (!$conn) {
        die("Error al conectar a la base de datos: " . mysqli_connect_error());
    }

    // Procesar el formulario de registro
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $espacio = $_POST["espacio"];
        $vehiculo = $_POST["vehiculo"];
        $horaEntrada = $_POST["hora_entrada"];
        
        // Validar y procesar los datos según tus necesidades
        
        // Insertar los datos en la base de datos
        $sql = "INSERT INTO Registro (espacio_id, vehiculo_id, hora_entrada) VALUES ('$espacio', '$vehiculo', '$horaEntrada')";
        
        if (mysqli_query($conn, $sql)) {
            // Marcar el espacio como ocupado en la tabla Espacio
            $sql_update = "UPDATE Espacios SET disponible = 0 WHERE id = '$espacio'";
            mysqli_query($conn, $sql_update);
            
            echo "Registro exitoso.";
        } else {
            echo "Error al registrar los datos: " . mysqli_error($conn);
        }
    }

    // Obtener los espacios disponibles
    $sql_espacios = "SELECT id FROM Espacios WHERE disponible = 1";
    $result_espacios = mysqli_query($conn, $sql_espacios);
    $espacios_disponibles = mysqli_fetch_all($result_espacios, MYSQLI_ASSOC);

    // Obtener los vehículos que no tienen un parqueadero asignado
    $sql_vehiculos = "SELECT V.id, V.marca, V.modelo FROM Vehiculos V LEFT JOIN Registro R ON V.id = R.vehiculo_id WHERE R.vehiculo_id IS NULL";
    $result_vehiculos = mysqli_query($conn, $sql_vehiculos);
    $vehiculos_registrados = mysqli_fetch_all($result_vehiculos, MYSQLI_ASSOC);
    ?>

    <div class="container">
        <h1>Registro de Parking</h1>
    
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="espacio">Espacio:</label>
            <select name="espacio" id="espacio" required>
                <?php
                foreach ($espacios_disponibles as $espacio) {
                    echo "<option value='" . $espacio["id"] . "'>" . $espacio["id"] . "</option>";
                }
                ?>
            </select><br><br>
            
            <label for="vehiculo">Vehículo:</label>
            <select name="vehiculo" id="vehiculo" required>
                <?php
                foreach ($vehiculos_registrados as $vehiculo) {
                    echo "<option value='" . $vehiculo["id"] . "'>" . $vehiculo["marca"] . " " . $vehiculo["modelo"] . "</option>";
                }
                ?>
            </select><br><br>
            
            <label for="hora_entrada">Hora de entrada:</label>
            <input type="datetime-local" name="hora_entrada" id="hora_entrada" required><br><br>
            
            <input type="submit" value="Registrar">
        </form>
    </div>
</body>
</html>
